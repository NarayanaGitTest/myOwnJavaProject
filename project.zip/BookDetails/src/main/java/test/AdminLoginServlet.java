package test;
import java.io.*;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/adminLog")
public class AdminLoginServlet extends HttpServlet
{
protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
{
	AdminBean ab=new AdminloginDA0().login(req.getParameter("uname"),req.getParameter("pword"));
	if(ab==null)
	{
		req.setAttribute("msg", "invalid login.......");
		RequestDispatcher rd=req.getRequestDispatcher("Home.jsp");
		rd.forward(req,res);
	}
	else
	{
		HttpSession sh=req.getSession();
		sh.setAttribute("abean",ab);
		req.getRequestDispatcher("AdminLogin.jsp").forward(req, res);
	}
}
}