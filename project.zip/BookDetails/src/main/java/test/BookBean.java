package test;
import java.io.Serializable;
public class BookBean implements Serializable
{
private String Code,Name,Author;
private Float Price;
private Integer Qty;
public BookBean() {}
public String getCode() {
	return Code;
}
public void setCode(String code) {
	Code = code;
}
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}
public String getAuthor() {
	return Author;
}
public void setAuthor(String author) {
	Author = author;
}
public Float getPrice() {
	return Price;
}
public void setPrice(Float price) {
	Price = price;
}
public Integer getQty() {
	return Qty;
}
public void setQty(Integer qty) {
	Qty = qty;
}

}
