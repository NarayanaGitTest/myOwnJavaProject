package test;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/login1")
public class CustomerLoginServlet extends HttpServlet
{
	protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		AdminBean ab=new CustomerLoginDAO().login(req.getParameter("uname"),req.getParameter("pword"));
		if(ab==null)
		{
			req.setAttribute("msg", "invalid login.......");
			RequestDispatcher rd=req.getRequestDispatcher("Home.jsp");
			rd.forward(req,res);
		}
		else
		{
			HttpSession sh=req.getSession(false);
			sh.setAttribute("abean",ab);
			req.getRequestDispatcher("Login.jsp").forward(req, res);
		}
	}
}
