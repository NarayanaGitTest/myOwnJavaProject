package test;

import java.io.IOException;
import java.io.Serializable;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/customerLog")

public class CustomerRegisterServlet extends HttpServlet
{
	protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		CustomerBean cb=new CustomerRegisterDAO().login(req.getParameter("uname"),req.getParameter("pword"));
		if(cb==null)
		{
			req.setAttribute("msg", "invalid login.......");
			RequestDispatcher rd=req.getRequestDispatcher("Home.jsp");
			rd.forward(req,res);
		}
		else
		{
			HttpSession hs1=req.getSession();
			hs1.setAttribute("cbean",cb);
			req.getRequestDispatcher("CustomerLogin.jsp").forward(req, res);
		}
	}
}
