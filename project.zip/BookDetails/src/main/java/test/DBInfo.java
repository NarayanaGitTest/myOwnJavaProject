package test;

public class DBInfo 
{
	public static final String dbUrl="jdbc:oracle:thin:@localhost:1521:xe";
	public static final String uName="narayana";
	public static final String pWord="nagaraju";
}
