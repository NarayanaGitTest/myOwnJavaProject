package test;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/cust")
public class NewCustomerServlet extends HttpServlet
{
	protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		HttpSession hs1=req.getSession(false);
		if(hs1==null)
		{
			req.setAttribute("msg", "session expired....");;
			RequestDispatcher rd=req.getRequestDispatcher("Home.jsp");
			rd.forward(req, res);
		}
		else
		{
		CustomerBean cb=new CustomerBean();
		cb.setUname(req.getParameter("code"));
		cb.setPword(req.getParameter("name"));
		cb.setfName(req.getParameter("fname"));
		cb.setlName(req.getParameter("lname"));
		cb.setAddr(req.getParameter("addr"));
		cb.setmId(req.getParameter("mid"));
		cb.setPhNo(Long.parseLong(req.getParameter("phno")));
		int  k=new NewCustomerDAO ().insert(cb);
	     if(k>0)
		{
			req.setAttribute("msg", " Added Successfully..<br>");
		}
	     RequestDispatcher rd=req.getRequestDispatcher("NewCustomer.jsp");
			rd.forward(req, res);
		}
	}
}
