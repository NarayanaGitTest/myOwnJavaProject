package test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ViewBookDetailsDAO {
    public ArrayList<BookBean> retrieve() {
        ArrayList<BookBean> al = new ArrayList<>();

        try {
            Connection con = DBConnection.getCon();
            PreparedStatement ps = con.prepareStatement("select * from  BookDetails57");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                BookBean bb = new BookBean();
                bb.setCode(rs.getString("code"));
                bb.setName(rs.getString("name"));
                bb.setAuthor(rs.getString("author"));
                bb.setPrice(rs.getFloat("price"));
                bb.setQty(rs.getInt("qty"));
                al.add(bb);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return al;
    }
}
