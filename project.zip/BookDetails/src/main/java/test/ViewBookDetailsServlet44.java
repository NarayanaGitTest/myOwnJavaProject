package test;
import java.io.*;
import java.util.ArrayList;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/view4")
public class ViewBookDetailsServlet44 extends HttpServlet
{
protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
{
	HttpSession hs=req.getSession(false);
	if(hs==null)
	{
		req.setAttribute("msg","invaild............<br>");
		RequestDispatcher rd=req.getRequestDispatcher("Home.jsp");
		rd.forward(req, res);
	}
	else
	{
		ArrayList<BookBean> al = new ViewBookDetailsDAO().retrieve();
		req.setAttribute("list", al);
		RequestDispatcher rd=req.getRequestDispatcher("ViewProfile44.jsp");
		rd.forward(req,res);
	
	}
	
	
}
}
